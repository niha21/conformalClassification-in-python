#global variables for sharing across multiple processes
trainData = []
trainTarget = []
testData = []
clsLabel =[0]
nrTrees = 10
