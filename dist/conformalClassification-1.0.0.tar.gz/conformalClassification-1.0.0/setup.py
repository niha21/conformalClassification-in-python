from setuptools import setup

setup(
    name='conformalClassification',
    version='1.0.0',
    packages=['conformalClassification'],
    url='',
    license='',
    author='Niharika',
    author_email='niharika.gauraha@farmbio.uu.se',
    description=''
)
